<!doctype html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Zadanie T11 - funkcje wbudowane</title>
    <link rel="stylesheet" href="styl.css" />
</head>
<body>
<header>
    <h1>Zadanie T11 - funkcje wbudowane</h1>
    <table>
        <tr>
            <td>Imię i nazwisko: </td>
            <td>Klasa/grupa: </td>
            <td>Data: </td>
        </tr>
        <tr>
            <td>Marcin Panter</td>
            <td>3ip_2</td>
            <td>16.11.2023</td>
        </tr>
    </table>
    <h2>Zadanie T113</h2>
    <p>Dane są dwie tablice. Napisz funkcję, która otrzymuje obie tablice w argumencie i zwraca posortowaną tablicę zawierającą wszystkie elementy z pierwszej i drugiej tablicy.</p>
</header>
<section>
    <?php
    function sortowaniePolaczonychTablic($t1, $t2){
        $n = sizeof($t1)+sizeof($t2);
        $tab = array();
        for($i = 0; $i < $n; $i++){
            if($i < sizeof($t1)){
                $tab[$i] = $t1[$i];
            } elseif($i < $n){
                $tab[$i] = $t2[$i-sizeof($t1)];
            }
        }
        sort($tab);
        return $tab;
    }

    $tab1 = array(1,5,4);
    $tab2 = array(15,0.5,8);

    echo "Dane są tablice: <br>";
    foreach ($tab1 as $x) {
        echo "$x ";
    }
    echo "<br>";
    foreach ($tab2 as $x) {
        echo "$x ";
    }
    echo "<br><br>Posortowana tablica składająca się z elementów z powyższych tablic:<br>";

    $tab3 = sortowaniePolaczonychTablic($tab1, $tab2);
    foreach ($tab3 as $x) {
        echo "$x ";
    }

    ?>
</section>
</body>
</html>
