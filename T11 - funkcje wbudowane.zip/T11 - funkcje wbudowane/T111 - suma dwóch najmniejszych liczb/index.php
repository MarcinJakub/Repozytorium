<!doctype html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Zadanie T11 - funkcje wbudowane</title>
    <link rel="stylesheet" href="styl.css" />
</head>
<body>
    <header>
        <h1>Zadanie T11 - funkcje wbudowane</h1>
        <table>
            <tr>
                <td>Imię i nazwisko: </td>
                <td>Klasa/grupa: </td>
                <td>Data: </td>
            </tr>
            <tr>
                <td>Marcin Panter</td>
                <td>3ip_2</td>
                <td>16.11.2023</td>
            </tr>
        </table>
        <h2>Zadanie T111</h2>
        <p>Dana jest tablica zawierająca liczby. Napisz funkcję, która po otrzymaniu tej tablicy jako argumentu zwraca sumę dwóch najmniejszych liczb zapisanych w tablicy.</p>
    </header>
    <section>
        <?php
        function sumaDwochNajmniejszych($t){
            return $suma = $t[0] + $t[1];
        }

        $tab = array(1.5,56,6,67,34,5,0.6);
        echo "Dana jest tablica: ";
        foreach($tab as $x){
            echo "$x ";
        }
        sort($tab);
        echo "<br>Suma dwóch najmniejszych wartości wynosi: ".sumaDwochNajmniejszych($tab);


        ?>
    </section>
</body>
</html>