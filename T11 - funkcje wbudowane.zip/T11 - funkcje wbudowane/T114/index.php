<!doctype html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Zadanie T11 - funkcje wbudowane</title>
    <link rel="stylesheet" href="styl.css" />
</head>
<body>
<header>
    <h1>Zadanie T11 - funkcje wbudowane</h1>
    <table>
        <tr>
            <td>Imię i nazwisko: </td>
            <td>Klasa/grupa: </td>
            <td>Data: </td>
        </tr>
        <tr>
            <td>Marcin Panter</td>
            <td>3ip_2</td>
            <td>16.11.2023</td>
        </tr>
    </table>
    <h2>Zadanie T114</h2>
    <p>Napisz funkcję, która dla podanej daty w postaci mm, dd, YY sprawdzi, czy jest to prawidłowa data i jeśli tak sprawdzi, czy jest to data z przeszłości. Jeśli tak funkcja wypisze słowo „historia”, a jeśli nie wypisze „teraźniejszość lub przyszłość”. W przypadku błędnej danej funkcja kończy działanie i wyświetla komunikat o błędnej dacie.</p>
    <form action="<?php echo $_SERVER['PHP_SELF']?>" method="post">
        <input type=""
        <input type="submit" value="Wyślij" />
    </form>
</header>
<section>
    <?php
    if (checkdate( $_GET['miesiac'], $_GET['dzien'], $_GET['rok'])) {

    } else {
        echo "<strong>Błąd!</strong>Podano niepoprawną datę";
    }
    ?>
</section>
</body>
</html>