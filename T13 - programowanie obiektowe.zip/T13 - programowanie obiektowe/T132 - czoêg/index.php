<!doctype html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Zadanie T13 - programowanie obiektowe</title>
</head>
<body>
<header>
    <h1>Zadanie T132</h1>
    <h2>Autor: Marcin Panter 3ip_2</h2>
    <p>Zdefiniuj klasę czołg. Czołg powinien mieć następujące właściwości:</p>
    <ul>
        <li>nazwa,</li>
        <li>kolor,</li>
        <li>ilość amunicji</li>
    </ul>
    <p>oraz metody:</p>
    <ul>
        <li>info() – wyświetlająca informację o czołgu,</li>
        <li>pomaluj() – zmieniająca kolor czołgu,</li>
        <li>załaduj() – zwiększająca ilość amunicji,</li>
        <li>strzelaj() – wyświetla komunikat i zmniejsza ilość amunicji o 1 (w wariancie rozwiniętym należy uniemożliwić wykonanie strzału jeśli nie ma amunicji).
            Utwórz obiekt klasy czołg i przetestuj działanie metod.</li>
    </ul>
</header>
<section>
    <?php
    class Czolg{
        public $nazwa, $kolor, $iloscAmunicji;
        function __construct(){
            
        }
    }
    ?>
</section>
</body>
</html>