<!doctype html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Zadanie T13 - programowanie obiektowe</title>
</head>
<body>
    <header>
        <h1>Zadanie T131</h1>
        <h2>Autor: Marcin Panter 3ip_2</h2>
        <p>Zdefiniuj klasę <b>Osoba</b> z dodanym polem wiek.</p>
    </header>
    <section>
        <?php
        class Osoba{
            public $id, $imie, $nazwisko, $wiek;
            function __construct($id, $imie, $nazwisko, $wiek){
                $this->id = $id;
                $this->imie = $imie;
                $this->nazwisko = $nazwisko;
                $this->wiek = $wiek;
            }
            function wpiszNazwisko($arg1)
            {
                $this->nazwisko = $arg1;
            }

            function pobierzNazwisko()
            {
                return $this->nazwisko;
            }

            function wpiszImie($arg2)
            {
                $this->imie = $arg2;
            }

            function pobierzImie()
            {
                return $this->imie;
            }

            function wpiszId($arg3)
            {
                $this->id = $arg3;
            }

            function pobierzId()
            {
                return $this->id;
            }
            function wpiszWiek($wiek){
                $this->wiek = $wiek;
            }
        }

        $postac1 = new Osoba(1,"Jan","Kowalski",17);
        ?>
    </section>
</body>
</html>