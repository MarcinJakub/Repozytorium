<!doctype html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Zadanie T09d - odwrócona</title>
    <link rel="stylesheet" href="styl.css" />
</head>
<body>
    <header>
        <h1>Zadanie T09d - odwrócona</h1>
        <h2>Autor: Marcin Panter 3ip_2</h2>
        <p>Napisz program, który tworzy dwuwymiarową tablicę o wymiarach 4 x 4 i wypełnia ją liczbami pseudolosowymi  z zakresu <0,1>, wyświetla tą tablicę z zachowaniem wierszy i kolumn, a następnie:

        <ol>
            <li>wyświetla te wiersze tablicy w których suma liczb jest największa,</li>
            <li>tworzy "odwróconą" tablicę (ostatni wiersz pierwszej tablicy jest pierwszą kolumną drugiej i tak dalej - tablica wygląda jak obrócona w prawo o 90o), a następnie wyświetla ją na ekranie.</li>
        </ol>

        przykład odwrócenia<br><br>

        0001<br>
        0010<br>
        0100<br>
        0100<br><br>

        tablica po odwróceniu:<br><br>

        0000<br>
        1100<br>
        0010<br>
        0001

        </p>
    </header>
    <section>
        <?php
        $array = array();

        for($i = 0; $i < 4; $i++){
            $array[$i] = [];
            for($j = 0; $j < 4; $j++){
                $rand = rand(0,1);
                $array[$i][$j] = $rand;
            }
        }

        for($i = 0; $i < 4; $i++){
            for($j = 0; $j < 4; $j++){
                echo $array[$i][$j];
                echo " ";
            }
            echo "<br>";
        }

        $array2 = array();
        for($i = 0; $i < 4; $i++){
            $array2[$i] = [];
            for($j = 0; $j < 4; $j++){
                $array2[$i][$j] = $array[][];
            }
        }
        echo "<br><br>";

        for($i = 0; $i < 4; $i++){
            for($j = 0; $j < 4; $j++){
                echo $array2[$i][$j];
                echo " ";
            }
            echo "<br>";
        }
        ?>
    </section>
</body>
</html>