<!doctype html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Zadanie ZDP - zamówienie dla piekarni</title>
    <link rel="stylesheet" href="style.css" />
</head>
<body>
    <header>
        <h1>Zadanie ZDP - zamówienie dla piekarni</h1>
        <h2>Autor: Marcin Panter 3ip_2</h2>
        <p>Zadanie polega na utworzeniu systemu umożliwiającego wykonanie zamówienia trzech produktów sprzedawanych w piekarni (dodaj własny pomysł). Użytkownik wypełnia formularz w którym zapisuje ilość zamówionych produktów. Skrypt oblicza należność za zamówione ilości produktów i wyświetla je w tabeli.</p>
    </header>
    <section>
        <h1></h1>
        <form action="<?php echo $_SERVER['PHP_SELF']?>" method="post">
            <table>
                <tr>
                    <th>Nasze produkty</th>
                    <td><img src="img/kajzerka.jpg"></td>
                    <td><img src="img/bagietka.jpg"></td>
                    <td><img src="img/dyniowa.jpg"></td>
                </tr>
                <tr>
                    <th>Nazwa</th>
                    <td>Kajzerka</td>
                    <td>Bagietka</td>
                    <td>Bułka dyniowa</td>
                </tr>
                <tr>
                    <th>Cena za szt.</th>
                    <td>1.99 zł</td>
                    <td>3.99 zł</td>
                    <td>2.49 zł</td>
                </tr>
                <tr>
                    <th>Podaj ilość</th>
                    <td><label for="kajzerka">ilość: </label><input type="text" id="kajzerka" name="kajzerka"></td>
                    <td><label for="bagietka">ilość: </label><input type="text" id="bagietka" name="bagietka"></td>
                    <td><label for="dyniowa">ilość: </label><input type="text" id="dyniowa" name="dyniowa"></td>
                </tr>
            </table><br>
            <label for="dostawa">Wybierz sposób dostawy:</label><select id="dostawa" name="dostawa">
                <option value="darmowy_odbiór_osobisty">darmowy odbiór osobisty</option>
                <option value="kurier">kurier (+7% ceny)</option>
                <option value="paczkomat">paczkomat(+5% ceny)</option>
            </select>

            <input type="checkbox" id="18" name="18">
            <label for="18"><b>Mam ukończone 18 lat</b></label><br><br>
            <input type="submit" value="Zamów" />
        </form><br>
        <?php
            if($_SERVER['REQUEST_METHOD'] == "POST"){
                if(isset($_POST['kazjerka'],$_POST['bagietka'],$_POST['dyniowa'], $_POST['dostawa']) &&
                    is_numeric($_POST['kajzerka'] && is_numeric($_POST['bagietka']) && is_numeric($_POST['dyniowa']))){
                    $kajzerka = (int)$_POST['kajzerka'];
                    $bagietka = (int)$_POST['bagietka'];
                    $dyniowa = (int)$_POST['dyniowa'];
                    $dostawa = (string)$_POST['dostawa'];

                    if($kajzerka >= 0 && $bagietka >= 0 && $dyniowa >= 0){
                        $c_kajzerka = $kajzerka * 1.99;
                        $c_bagietka = $bagietka * 3.99;
                        $c_dyniowa = $dyniowa * 2.49;

                        $cena = $c_kajzerka + $c_bagietka + $c_dyniowa;

                        switch($dostawa){
                            case "darmowy_odbior_osobisty":
                                $cena *= 1;
                            case "kurier":
                                $cena *= 1.07;
                            case "paczkomat":
                                $cena *= 1.05;
                        }
                    } else{
                        echo "<p><b style='color: darkred'>Błąd!</b> Podano nieprawidłową wartość w ilości zamówionych produktów!</p>";
                    }
                }
            }
        ?>
    </section>
    <footer>
        <h3>Kontakt</h3>
        <p><b>Nr. telefonu:</b> 123 456 789</p>
    </footer>
</body>
</html>